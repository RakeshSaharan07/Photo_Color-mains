# Photo-colors
This is a program is used to detect colour of picture
